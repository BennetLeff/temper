//! Native copper binding for the PFC current envelope model.
//!
//! This module deliberately only uses geometry which the native exporter
//! supplied.  In particular, a pad is not connected to a track merely because
//! its bounding boxes overlap: the exporter gives us a centre point and this
//! adapter requires a centre hit (or reports a coverage gap).

use std::collections::BTreeMap;
use zapote_core::unit::UnitNativeEvidence;
use zapote_drc::power_branches::{Edge, Graph};

const EPS: f64 = 1e-5;
const MODELED_COMPONENTS: &[&str] = &[
    "mains", "holder", "cmc", "ntc", "bypass", "bridge", "l_boost", "q_boost", "d_boost", "c1",
    "c2", "c3", "c4", "c_hf", "output", "shunt",
];

#[derive(Debug, Clone)]
pub struct BoundGraph {
    pub graph: Graph,
    pub terminal_nodes: BTreeMap<String, usize>,
    pub edge_width_mm: BTreeMap<String, f64>,
    pub edge_kind: BTreeMap<String, String>,
    pub coverage_gaps: Vec<String>,
}

#[derive(Clone, Copy, Debug, PartialEq)]
struct Point([f64; 2]);

impl Point {
    fn dist2(self, other: Self) -> f64 {
        (self.0[0] - other.0[0]).powi(2) + (self.0[1] - other.0[1]).powi(2)
    }
}

fn point_on(a: Point, b: Point, p: Point) -> Option<f64> {
    let dx = b.0[0] - a.0[0];
    let dy = b.0[1] - a.0[1];
    let len2 = dx * dx + dy * dy;
    if len2 <= EPS * EPS {
        return None;
    }
    let t = ((p.0[0] - a.0[0]) * dx + (p.0[1] - a.0[1]) * dy) / len2;
    let q = Point([a.0[0] + t * dx, a.0[1] + t * dy]);
    (t >= -EPS && t <= 1.0 + EPS && q.dist2(p) <= EPS * EPS).then_some(t.clamp(0.0, 1.0))
}

fn point_segment_distance(a: Point, b: Point, p: Point) -> f64 {
    let dx = b.0[0] - a.0[0];
    let dy = b.0[1] - a.0[1];
    let len2 = dx * dx + dy * dy;
    let t = if len2 <= EPS * EPS {
        0.0
    } else {
        (((p.0[0] - a.0[0]) * dx + (p.0[1] - a.0[1]) * dy) / len2).clamp(0.0, 1.0)
    };
    Point([a.0[0] + t * dx, a.0[1] + t * dy]).dist2(p).sqrt()
}

fn intersection(a: Point, b: Point, c: Point, d: Point) -> Option<Point> {
    let (rx, ry) = (b.0[0] - a.0[0], b.0[1] - a.0[1]);
    let (sx, sy) = (d.0[0] - c.0[0], d.0[1] - c.0[1]);
    let den = rx * sy - ry * sx;
    if den.abs() <= EPS {
        return None;
    }
    let qpx = c.0[0] - a.0[0];
    let qpy = c.0[1] - a.0[1];
    let t = (qpx * sy - qpy * sx) / den;
    let u = (qpx * ry - qpy * rx) / den;
    (t >= -EPS && t <= 1.0 + EPS && u >= -EPS && u <= 1.0 + EPS)
        .then_some(Point([a.0[0] + t * rx, a.0[1] + t * ry]))
}

fn copper(layer: &str) -> bool {
    layer == "F.Cu" || layer == "B.Cu" || layer.ends_with(".Cu")
}
fn key(net: &str, layer: &str, p: Point) -> (String, String, i64, i64) {
    (
        net.into(),
        layer.into(),
        (p.0[0] / EPS).round() as i64,
        (p.0[1] / EPS).round() as i64,
    )
}
fn node_index(
    nodes: &mut BTreeMap<(String, String, i64, i64), usize>,
    net: &str,
    layer: &str,
    p: Point,
) -> usize {
    let n = nodes.len();
    *nodes.entry(key(net, layer, p)).or_insert(n)
}
fn add_edge(
    edges: &mut Vec<Edge>,
    widths: &mut BTreeMap<String, f64>,
    kinds: &mut BTreeMap<String, String>,
    id: String,
    net: &str,
    from: usize,
    to: usize,
    width: f64,
    kind: &str,
) {
    if from == to || edges.iter().any(|e| e.id == id) {
        return;
    }
    edges.push(Edge {
        id: id.clone(),
        net: net.into(),
        from,
        to,
    });
    widths.insert(id.clone(), width);
    kinds.insert(id, kind.into());
}

/// Construct a graph from native trace, via, pad and filled-zone geometry.
pub fn build(native: &UnitNativeEvidence) -> Result<BoundGraph, String> {
    if native.traces.is_empty() && native.vias.is_empty() {
        return Err("native PFC evidence has no copper traces or vias".into());
    }
    for trace in &native.traces {
        if trace.id.trim().is_empty() || trace.net.trim().is_empty() || trace.points_mm.len() < 2 {
            return Err(format!("invalid native trace {}", trace.id));
        }
    }
    let mut pads = Vec::new();
    for component in &native.components {
        for pad in &component.footprint_pads {
            // Mechanical NPTH mounting holes are represented as pads with no
            // number and no net. They are board geometry, not terminals.
            if pad.net.trim().is_empty() {
                if pad.pad.trim().is_empty() {
                    continue;
                }
                return Err(format!("unknown net at {}.{}", component.id, pad.pad));
            }
            let layers: Vec<_> = pad.layers.iter().filter(|l| copper(l)).cloned().collect();
            if layers.is_empty() {
                continue;
            }
            pads.push((
                format!("{}.{}", component.id, pad.pad),
                pad.net.clone(),
                Point(pad.position_mm),
                layers,
                pad.drill_mm,
                pad.size_mm,
            ));
        }
    }
    let mut candidates: Vec<(String, String, Point)> = Vec::new();
    for trace in &native.traces {
        for p in &trace.points_mm {
            candidates.push((trace.net.clone(), trace.layer.clone(), Point(*p)));
        }
    }
    for (_, net, p, layers, _, _) in &pads {
        for layer in layers {
            candidates.push((net.clone(), layer.clone(), *p));
        }
    }
    for via in &native.vias {
        candidates.push((
            via.net.clone(),
            via.from_layer.clone(),
            Point(via.position_mm),
        ));
        candidates.push((
            via.net.clone(),
            via.to_layer.clone(),
            Point(via.position_mm),
        ));
    }
    // Add trace crossings and T-junctions before splitting any segment.
    for a in 0..native.traces.len() {
        for b in a..native.traces.len() {
            if native.traces[a].net != native.traces[b].net {
                continue;
            }
            if native.traces[a].layer != native.traces[b].layer {
                continue;
            }
            for aw in native.traces[a].points_mm.windows(2) {
                for bw in native.traces[b].points_mm.windows(2) {
                    if let Some(p) =
                        intersection(Point(aw[0]), Point(aw[1]), Point(bw[0]), Point(bw[1]))
                    {
                        candidates.push((
                            native.traces[a].net.clone(),
                            native.traces[a].layer.clone(),
                            p,
                        ));
                    }
                }
            }
        }
    }
    let mut nodes = BTreeMap::<(String, String, i64, i64), usize>::new();
    let mut edges = Vec::new();
    let mut widths = BTreeMap::new();
    let mut kinds = BTreeMap::new();
    for trace in &native.traces {
        for (seg, window) in trace.points_mm.windows(2).enumerate() {
            let a = Point(window[0]);
            let b = Point(window[1]);
            let mut cuts = vec![(0.0, a), (1.0, b)];
            for (net, layer, p) in &candidates {
                if net == &trace.net && layer == &trace.layer {
                    if let Some(t) = point_on(a, b, *p) {
                        cuts.push((t, *p));
                    }
                }
            }
            cuts.sort_by(|x, y| x.0.total_cmp(&y.0));
            cuts.dedup_by(|x, y| (x.0 - y.0).abs() <= EPS);
            for (part, pair) in cuts.windows(2).enumerate() {
                let from = node_index(&mut nodes, &trace.net, &trace.layer, pair[0].1);
                let to = node_index(&mut nodes, &trace.net, &trace.layer, pair[1].1);
                add_edge(
                    &mut edges,
                    &mut widths,
                    &mut kinds,
                    format!("{}:{}", trace.id, seg * 10000 + part),
                    &trace.net,
                    from,
                    to,
                    if trace.id.starts_with("pad-contact:") {
                        0.0
                    } else {
                        trace.width_mm
                    },
                    if trace.id.starts_with("pad-contact:") {
                        "pad-contact"
                    } else {
                        "trace"
                    },
                );
            }
        }
    }
    for via in &native.vias {
        if via.net.trim().is_empty() {
            return Err(format!("via {} has unknown net", via.id));
        }
        let p = Point(via.position_mm);
        let from = node_index(&mut nodes, &via.net, &via.from_layer, p);
        let to = node_index(&mut nodes, &via.net, &via.to_layer, p);
        add_edge(
            &mut edges,
            &mut widths,
            &mut kinds,
            format!("via:{}", via.id),
            &via.net,
            from,
            to,
            via.diameter_mm,
            "via",
        );
    }
    let mut terminal_nodes = BTreeMap::new();
    let mut gaps = Vec::new();
    for (name, net, p, layers, drill, size) in pads {
        let first = node_index(&mut nodes, &net, &layers[0], p);
        terminal_nodes.insert(name.clone(), first);
        if drill[0] > 0.0 || drill[1] > 0.0 {
            for layer in layers.iter().skip(1) {
                let n = node_index(&mut nodes, &net, layer, p);
                add_edge(
                    &mut edges,
                    &mut widths,
                    &mut kinds,
                    format!("pad:{}:{}", name, layer),
                    &net,
                    first,
                    n,
                    0.0,
                    "pth-pad",
                );
            }
        }
        let centre_hit = native.traces.iter().any(|t| {
            t.net == net
                && layers.contains(&t.layer)
                && t.points_mm
                    .windows(2)
                    .any(|w| point_on(Point(w[0]), Point(w[1]), p).is_some())
        });
        if !centre_hit {
            let radius = 0.5 * size[0].max(size[1]);
            let side_hit = native.traces.iter().any(|t| {
                t.net == net
                    && layers.contains(&t.layer)
                    && t.points_mm.windows(2).any(|w| {
                        point_segment_distance(Point(w[0]), Point(w[1]), p)
                            <= radius + t.width_mm / 2.0 + EPS
                    })
            });
            gaps.push(if side_hit {
                format!("terminal {name} on {net} has possible unsupported side/width-only contact; centreline binding is unsupported")
            } else {
                format!("terminal {name} on {net} has no centreline copper hit")
            });
        }
    }
    // Filled zones are explicit conductors.  Holes are excluded by point-in-polygon.
    for zone in &native.zones {
        for (polygon, poly) in zone.filled_polygons.iter().enumerate() {
            let inside = |p: Point| {
                polygon_contains(&poly.outer_mm, p)
                    && !poly.holes_mm.iter().any(|h| polygon_contains(h, p))
            };
            let targets: Vec<_> = nodes
                .iter()
                .filter_map(|((net, layer, x, y), &n)| {
                    (net == &zone.net
                        && layer == &zone.layer
                        && inside(Point([*x as f64 * EPS, *y as f64 * EPS])))
                    .then_some(n)
                })
                .collect();
            let zn = node_index(&mut nodes, &zone.net, &zone.layer, Point(poly.outer_mm[0]));
            for target in targets {
                add_edge(
                    &mut edges,
                    &mut widths,
                    &mut kinds,
                    format!(
                        "zone:{}:{}:{}:{}",
                        zone.id,
                        layer_tag(&zone.layer),
                        polygon,
                        target
                    ),
                    &zone.net,
                    zn,
                    target,
                    0.0,
                    "zone",
                );
            }
        }
    }
    // Compare only the explicitly modeled high-power population. This keeps
    // unrelated low-current board clusters from affecting the PFC certificate.
    let mut parent: Vec<usize> = (0..nodes.len()).collect();
    fn root(parent: &mut [usize], mut n: usize) -> usize {
        while parent[n] != n {
            parent[n] = parent[parent[n]];
            n = parent[n];
        }
        n
    }
    for edge in &edges {
        let a = root(&mut parent, edge.from);
        let b = root(&mut parent, edge.to);
        if a != b {
            parent[a] = b;
        }
    }
    for cluster in &native.connectivity_clusters {
        if !cluster.nodes.iter().any(|name| {
            MODELED_COMPONENTS
                .iter()
                .any(|component| name.starts_with(&format!("{component}.")))
        }) {
            continue;
        }
        let members: Vec<_> = cluster
            .nodes
            .iter()
            .filter_map(|name| terminal_nodes.get(name).copied())
            .collect();
        if members.len() != cluster.nodes.len() {
            gaps.push(format!(
                "native connectivity cluster on {} contains an unbound terminal",
                cluster.net
            ));
        } else if let Some(&first) = members.first() {
            let first_root = root(&mut parent, first);
            if members.iter().any(|n| root(&mut parent, *n) != first_root) {
                gaps.push(format!(
                    "native connectivity cluster on {} is split in bound copper graph",
                    cluster.net
                ));
            }
        }
    }
    Ok(BoundGraph {
        graph: Graph {
            node_count: nodes.len(),
            edges,
        },
        terminal_nodes,
        edge_width_mm: widths,
        edge_kind: kinds,
        coverage_gaps: gaps,
    })
}

/// Bind manufacturer supplied copper pad polygons into the centreline model.
/// This is the only path which permits a trace-to-pad connection away from the
/// pad centre, and it does so by adding the measured copper intersection and a
/// short in-pad conductor; it never joins pads on net name alone.
pub fn build_with_manufacturing(
    native: &UnitNativeEvidence,
    receipt: &serde_json::Value,
) -> Result<BoundGraph, String> {
    let mut augmented = native.clone();
    let pads = receipt
        .pointer("/input/pads")
        .and_then(|v| v.as_array())
        .ok_or_else(|| "manufacturing receipt has no input.pads".to_string())?;
    for item in pads {
        let Some(vertices) = item
            .get("copper")
            .and_then(|v| v.get("vertices_mm"))
            .and_then(|v| v.as_array())
        else {
            continue;
        };
        let polygon: Vec<[f64; 2]> = vertices
            .iter()
            .filter_map(|p| {
                let a = p.as_array()?;
                Some([a.first()?.as_f64()?, a.get(1)?.as_f64()?])
            })
            .collect();
        if polygon.len() < 3 {
            continue;
        }
        let Some(id) = item.get("id").and_then(|v| v.as_str()) else {
            continue;
        };
        let layer = id
            .split('@')
            .nth(1)
            .and_then(|s| s.split(':').next())
            .unwrap_or("");
        if !copper(layer) {
            continue;
        }
        // Match the receipt polygon to the transport pad by its measured
        // centre, since the manufacturing receipt intentionally uses U refs.
        let centre = polygon
            .iter()
            .fold([0.0, 0.0], |mut s, p| {
                s[0] += p[0];
                s[1] += p[1];
                s
            })
            .map(|v| v / polygon.len() as f64);
        let Some((terminal, net, pad_centre)) = native
            .components
            .iter()
            .flat_map(|c| {
                c.footprint_pads
                    .iter()
                    .map(move |p| (format!("{}.{}", c.id, p.pad), p.net.clone(), p.position_mm))
            })
            .find(|(_, net, p)| !net.is_empty() && Point(*p).dist2(Point(centre)) < 0.04)
        else {
            continue;
        };
        let mut contacts = Vec::new();
        for trace in &native.traces {
            if trace.net != net || trace.layer != layer {
                continue;
            }
            for (segment, w) in trace.points_mm.windows(2).enumerate() {
                let a = Point(w[0]);
                let b = Point(w[1]);
                let hit = polygon
                    .iter()
                    .zip(polygon.iter().cycle().skip(1))
                    .take(polygon.len())
                    .find_map(|(x, y)| intersection(a, b, Point(*x), Point(*y)))
                    .or_else(|| point_in_polygon(&polygon, a).then_some(a))
                    .or_else(|| point_in_polygon(&polygon, b).then_some(b));
                if let Some(hit) = hit {
                    contacts.push((trace.id.clone(), segment, hit, trace.width_mm));
                }
            }
        }
        for (trace_id, segment, hit, width) in contacts {
            augmented.traces.push(zapote_core::Trace {
                id: format!("pad-contact:{terminal}:{trace_id}:{segment}"),
                net: net.clone(),
                points_mm: vec![hit.0, pad_centre],
                layer: layer.to_string(),
                width_mm: width,
            });
        }
    }
    // Keep the measured contact traces in the returned geometry; their IDs
    // retain both the terminal and native trace identity for audit output.
    build(&augmented)
}

fn point_in_polygon(poly: &[[f64; 2]], p: Point) -> bool {
    if poly.iter().any(|v| Point(*v).dist2(p) <= EPS * EPS) {
        return true;
    }
    let mut inside = false;
    for (a, b) in poly
        .iter()
        .zip(poly.iter().cycle().skip(1))
        .take(poly.len())
    {
        if ((a[1] > p.0[1]) != (b[1] > p.0[1]))
            && p.0[0] < (b[0] - a[0]) * (p.0[1] - a[1]) / (b[1] - a[1]) + a[0]
        {
            inside = !inside;
        }
    }
    inside
}

fn layer_tag(layer: &str) -> &str {
    layer
}
fn polygon_contains(poly: &[[f64; 2]], p: Point) -> bool {
    if poly.len() < 3 {
        return false;
    }
    let mut inside = false;
    for (a, b) in poly
        .iter()
        .zip(poly.iter().cycle().skip(1))
        .take(poly.len())
    {
        if ((a[1] > p.0[1]) != (b[1] > p.0[1]))
            && p.0[0] < (b[0] - a[0]) * (p.0[1] - a[1]) / (b[1] - a[1]) + a[0]
        {
            inside = !inside;
        }
    }
    inside
}

#[cfg(test)]
mod tests {
    use super::*;
    use zapote_core::unit::UnitNativeEvidence;

    fn evidence(value: serde_json::Value) -> UnitNativeEvidence {
        serde_json::from_value(value).expect("valid native fixture")
    }

    #[test]
    fn native11_binds_nonempty_graph_and_terminals() {
        let raw = include_str!("../../../power-entry/evidence/native-11.json");
        let native: UnitNativeEvidence = serde_json::from_str(raw).unwrap();
        let bound = build(&native).unwrap();
        assert!(bound.graph.edges.len() > native.traces.len());
        assert!(bound.terminal_nodes.len() > 20);
        assert!(bound
            .edge_width_mm
            .keys()
            .all(|id| bound.edge_kind.contains_key(id)));
        let zone_ids: Vec<_> = bound
            .graph
            .edges
            .iter()
            .filter(|edge| edge.id.starts_with("zone:"))
            .map(|edge| edge.id.as_str())
            .collect();
        let unique: std::collections::BTreeSet<_> = zone_ids.iter().copied().collect();
        assert_eq!(zone_ids.len(), unique.len());
        assert!(bound
            .coverage_gaps
            .iter()
            .any(|gap| gap.contains("PFC_BUS_MINUS is split")));
    }

    #[test]
    fn t_branch_is_split_at_junction() {
        let native = evidence(serde_json::json!({
            "board_sha256":"x", "extractor_sha256":"x", "copper_layer_count":2,
            "components":[
                {"id":"source","mpn":"m","kind":"x","position_mm":[0,0],"footprint_pads":[{"pad":"1","net":"PFC_BUS_PLUS","position_mm":[0,0],"size_mm":[1,1],"layers":["F.Cu"]}]},
                {"id":"left","mpn":"m","kind":"x","position_mm":[10,0],"footprint_pads":[{"pad":"1","net":"PFC_BUS_PLUS","position_mm":[10,0],"size_mm":[1,1],"layers":["F.Cu"]}]},
                {"id":"right","mpn":"m","kind":"x","position_mm":[5,5],"footprint_pads":[{"pad":"1","net":"PFC_BUS_PLUS","position_mm":[5,5],"size_mm":[1,1],"layers":["F.Cu"]}]}
            ], "connections":[], "connectivity_clusters":[],
            "traces":[
                {"id":"trunk","net":"PFC_BUS_PLUS","points_mm":[[0,0],[10,0]],"layer":"F.Cu","width_mm":1},
                {"id":"spur","net":"PFC_BUS_PLUS","points_mm":[[5,5],[5,0]],"layer":"F.Cu","width_mm":0.5}
            ], "vias":[], "zones":[]
        }));
        let bound = build(&native).unwrap();
        assert!(
            bound
                .graph
                .edges
                .iter()
                .filter(|e| e.id.starts_with("trunk:"))
                .count()
                >= 2
        );
        assert!(bound.graph.edges.iter().any(|e| e.id.starts_with("spur:")));
    }

    #[test]
    fn unknown_terminal_net_is_an_adapter_error() {
        let native = evidence(serde_json::json!({
            "board_sha256":"x", "extractor_sha256":"x", "copper_layer_count":2,
            "components":[{"id":"bad","mpn":"m","kind":"x","position_mm":[0,0],"footprint_pads":[{"pad":"1","net":"","position_mm":[0,0],"size_mm":[1,1],"layers":["F.Cu"]}]}],
            "connections":[], "connectivity_clusters":[], "traces":[{"id":"t","net":"X","points_mm":[[0,0],[1,0]],"layer":"F.Cu","width_mm":1}], "vias":[], "zones":[]
        }));
        assert!(build(&native).unwrap_err().contains("unknown net"));
    }
}
