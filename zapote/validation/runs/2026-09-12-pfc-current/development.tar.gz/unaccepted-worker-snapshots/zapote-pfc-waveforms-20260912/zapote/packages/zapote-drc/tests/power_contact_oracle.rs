use serde::Deserialize;
use zapote_drc::manufacturing::Polygon;
use zapote_drc::power_contact::entry;

#[derive(Deserialize)]
struct Fixture {
    trace: Trace,
    pad: Polygon,
    drill: Polygon,
}
#[derive(Deserialize)]
struct Trace {
    start_mm: [f64; 2],
    end_mm: [f64; 2],
    width_mm: f64,
}

fn fixture() -> Fixture {
    serde_json::from_str(include_str!("../../../validation/p1-current/contact-oracle.json")).unwrap()
}

#[test]
fn native_rotated_oval_and_oblong_drill_provide_contact_certificate() {
    let f = fixture();
    let result = entry(
        &[f.pad.clone()],
        Some(&f.drill),
        f.trace.start_mm,
        f.trace.end_mm,
        f.trace.width_mm,
    )
    .unwrap();
    assert!(result.certified_chord_mm >= f.trace.width_mm - 1e-9);
    assert!(result.full_width_chord_observed);
    assert!(result.sections_examined > 0);

    // An independently chosen 3.05 mm trace exceeds the native 3 mm pad
    // minor dimension, so the real entry routine must reject full width.
    let mutated = entry(&[f.pad], Some(&f.drill), f.trace.start_mm, f.trace.end_mm, 3.05).unwrap();
    assert!(!mutated.full_width_chord_observed);
}
