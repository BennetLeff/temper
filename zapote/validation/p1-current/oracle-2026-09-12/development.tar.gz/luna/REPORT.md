# ngspice independent PFC switching oracle

Date: 2026-09-12, `/opt/homebrew/bin/ngspice -v`: ngspice-45.2, KLU Direct Linear Solver.

The deck `boost_peak_170V.cir` is an independent fixed-line peak case: `Vin=169.7056275 V` (120 Vrms peak), `Vbus=389.615 V`, `L=180 uH`, `fs=129 kHz`, nominal duty parameter `0.564306`, and a stiff 10 mF bus with 1 mOhm source impedance. The switch is a voltage controlled switch with an explicit 1 mOhm branch sense resistor. The diode path is represented by a piecewise ideal behavioral current source plus 100 mOhm series path; the first physical-Diode version was retained only through its outcome below because it repeatedly hit timestep failure at the diode internal node.

Independent nominal local expectations (for 21.2132 A inductor average, before diode/switch parasitics):

* `D = 1 - Vin/Vbus = 0.564306`
* ripple `Delta-I = Vin*D/(L*fs) = 4.12429 A p-p`
* triangular-ripple inductor RMS `sqrt(Iavg^2 + Delta-I^2/12) = 21.2466 A`
* ideal switch RMS `Iavg*sqrt(D) = 15.9354 A`.

Successful actual transient solves (window 20--40 us, 20 n output step then 10 n output step):

| deck/log | rows | iL avg | iL RMS | iL min..max | reported switch sense RMS | bus avg |
|---|---:|---:|---:|---:|---:|---:|
| `boost_peak_170V_max20n.log` | 3302 | 4.03937 A | 4.21885 A | 1.56482..6.43398 A | 16.3491 A | 389.607 V |
| `boost_peak_170V_max10n.log` | 5426 | 4.03943 A | 4.21885 A | 1.56482..6.43388 A | 23.0825 A | 389.607 V |

The inductor waveform and bus voltage are stable under timestep refinement (relative change below 2e-5 for RMS, below 2e-5 A for extrema). The switch sense RMS is not trustworthy as currently wired because the controlled-switch branch and sense resistor include numerical current through the switch model; do not use it as a contract check. The inductor is only ~4 A because the startup from zero was not a settled 21.2 A CCM operating point.

Convergence limitations are preserved in command history/log outcomes: a physical-Diode deck at 500 us aborted around 51.9 us at timestep 2.9e-22 s (`d1#internal`); with UIC it aborted at 1.0 ns. The behavioral-diode deck with 20 ns max step solved 40 us cleanly; extending it to 500 us aborted around 36.4 us at `swmod-instance s1`. Therefore this is evidence for local switching transient integration and numerical refinement, not evidence of a line-cycle RMS or a settled nominal 15 Arms CCM waveform. It should not be merged as a production test without a robust startup/initial-condition formulation and an independently validated branch-current probe.

## Initialized CCM follow-up

`ccm_170V_init.cir` is the corrected local oracle: an inductor `IC` sets the known valley current (`Iavg=20 A - Delta-I/2`), `.tran ... UIC` makes that imposed initial condition explicit, the bus is an ideal stiff voltage source, and both branch currents are measured through zero-volt sense sources. The diode is a voltage-controlled switch driven by `V(sw)-V(bus)` with 1 µOhm/1 GOhm states. The 100 us measurement interval is exactly 12,900 PWM periods.

At 170 V fixed input, the 10 ns and 5 ns maximum-step runs both converged:

| log | iL avg | iL RMS | iL min..max | switch RMS | diode RMS | bus avg |
|---|---:|---:|---:|---:|---:|---:|
| `ccm_170V_init_max10n.log` | 20.03713 A | 20.0727 A | 17.95786..22.10516 A | 15.1258 A | 13.1956 A | 389.6150 V |
| `ccm_170V_init_max5n.log` | 20.03714 A | 20.0727 A | 17.95786..22.10516 A | 15.1258 A | 13.1956 A | 389.6150 V |

The independent ideal expectation using the deck's exact `D=1-170/389.615=0.563672` and `Delta-I=4.1268 A` is `iL_RMS=20.0354 A`, `switch_RMS=15.0422 A`, `diode_RMS=13.2344 A`; the small branch differences are attributable to the deliberately finite switch resistance and the deck duty parameter rounded to 0.56361. Timestep refinement changes all reported values below 1e-6 relative. This is valid local fixed-phase CCM evidence; it does not establish line-cycle/controller behavior.

## Corrected integer-cycle runs

The prior `100 us`/`12,900 periods` statement was wrong by 1000x. The corrected decks use `TPER=1/FSW`, `PULSE(... {DUTY*TPER} {TPER})`, and `FROM={10*TPER} TO={20*TPER}`: 10 measured PWM periods (77.5194 us) after 10 cycles of imposed CCM initialization. Duty is exact `1-VIN/VBUS`, and IC is exact `20 A - Delta-I/2`.

All three fixed-voltage cases converged at 5 ns maximum step:

| Vin | iL avg | iL RMS | min..max | switch RMS | diode RMS |
|---:|---:|---:|---:|---:|---:|
| 50 V | 20.0390 A | 20.0463 A | 19.0875..20.9899 A | 18.7174 A | 7.1773 A |
| 120 V | 20.0397 A | 20.0662 A | 18.2381..21.8401 A | 16.6940 A | 11.1339 A |
| 170 V | 20.0401 A | 20.0755 A | 17.9629..22.1158 A | 15.0739 A | 13.2590 A |

Artifacts: `ccm_{50,120}V_init.cir`, `ccm_{50,120}V_max5n.log`, and `ccm_170V_exact_max5n.log`. These are local fixed-phase switching checks; they do not support whole-line acceptance.
