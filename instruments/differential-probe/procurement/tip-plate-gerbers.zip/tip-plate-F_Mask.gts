%TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*%
%TF.CreationDate,2026-10-20T18:59:42-06:00*%
%TF.ProjectId,tip-plate,7469702d-706c-4617-9465-2e6b69636164,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-10-20 18:59:42*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,4.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,S1*%
X32500000Y-82735000D03*
%TD*%
%TO.C,S2*%
X127500000Y-82735000D03*
%TD*%
%TO.C,S3*%
X32500000Y-37265000D03*
%TD*%
%TO.C,S4*%
X127500000Y-37265000D03*
%TD*%
M02*
